#!/bin/bash
chmod +x /home/ubuntu/*.sh
chown -R ubuntu:ubuntu /home/ubuntu
