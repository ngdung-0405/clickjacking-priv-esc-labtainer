#!/bin/bash
echo ""
echo "###################################################"
echo "#  KICH BAN CLICKJACKING - CHAY TOAN BO          #"
echo "###################################################"
echo ""

echo "[BUOC 1] Dang nhap vao he thong..."
bash /home/ubuntu/step1_open_login.sh
echo ""

echo "[BUOC 2] Truy cap trang game cua attacker..."
bash /home/ubuntu/step2_open_game.sh
echo ""

echo "[BUOC 3] Kiem tra ket qua..."
bash /home/ubuntu/step3_check_result.sh
echo ""

echo "[BUOC 4] Phan tich iframe an..."
bash /home/ubuntu/step4_inspect_iframe.sh
echo ""

echo "###################################################"
echo "#  HOAN THANH                                    #"
echo "###################################################"
