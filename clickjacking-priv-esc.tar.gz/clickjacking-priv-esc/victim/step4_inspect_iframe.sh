#!/bin/bash
echo "========================================================"
echo "BUOC 4 (Nghien cuu): Phan tich trang game de tim iframe an"
echo "========================================================"
echo ""
echo "Tai source HTML cua trang game:"
curl -s http://192.168.10.50/game.html > /tmp/game_source.html

echo "--- Tim iframe trong source ---"
grep -n "iframe\|evil-frame\|opacity" /tmp/game_source.html | head -20

echo ""
echo "--- Ket luan ---"
if grep -q "opacity: 0.001" /tmp/game_source.html; then
    echo "[PHAT HIEN] iframe AN voi opacity: 0.001"
    echo "[PHAT HIEN] iframe dang load: $(grep -o 'src=\"[^\"]*\"' /tmp/game_source.html | head -1)"
    echo "iframe_found=yes"
else
    echo "[?] Khong tim thay iframe an ro rang"
    echo "iframe_found=no"
fi
echo "========================================================"
