#!/bin/bash
echo "========================================================"
echo "BUOC 1: Mo trinh duyet Firefox den trang dang nhap"
echo "========================================================"
echo ""
echo "URL: http://172.20.0.10/login"
echo ""
echo "Hay thuc hien trong Firefox:"
echo "  1. Nhap ten dang nhap: student"
echo "  2. Nhap mat khau    : password123"
echo "  3. Nhan nut [Dang Nhap]"
echo "  4. Kiem tra da thay trang Dashboard"
echo ""
echo "Khi xong -> Quay lai terminal nay, nhan Enter de tiep tuc..."
echo "========================================================"

# Mo Firefox
firefox http://172.20.0.10/login &
FFPID=$!

# Cho victim thao tac
read -p "Nhan Enter sau khi da dang nhap thanh cong..."

# Xac nhan login bang curl (kiem tra server con chay)
RESP=$(curl -s -o /dev/null -w "%{http_code}" http://172.20.0.10/login)
if [ "$RESP" = "200" ]; then
    echo "[OK] Target-web dang hoat dong binh thuong."
    echo "victim_opened_login=yes"
else
    echo "[LOI] Khong the ket noi toi target-web!"
    echo "victim_opened_login=no"
fi
