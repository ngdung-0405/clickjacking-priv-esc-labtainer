=== VICTIM (192.168.10.10) ===
Chay theo thu tu:

  ./step1_open_login.sh    # Mo Firefox -> dang nhap vao target-web
  ./step2_open_game.sh     # Mo Firefox -> truy cap game -> click "Nhan Qua"
  ./step3_check_result.sh  # Kiem tra tan cong co thanh cong khong
  ./step4_inspect_iframe.sh # Phan tich iframe an trong trang game

Hoac chay tat ca 1 lenh:
  ./run_full_attack.sh

LUU Y QUAN TRONG:
  Phai chay step1 TRUOC (can co session cookie trong Firefox)
  Roi moi chay step2 (iframe se dung session cookie do gui POST)
