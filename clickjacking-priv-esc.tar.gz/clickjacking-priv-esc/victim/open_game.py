#!/usr/bin/env python3
import urllib.request

url = 'http://192.168.10.50/game.html'
print('[victim] Dang mo trang game: %s' % url)
try:
    resp = urllib.request.urlopen(url, timeout=5)
    html = resp.read().decode(errors='ignore')
    if 'iframe' in html:
        print('[victim] Phat hien iframe an load: http://172.20.0.10/admin/settings')
    print('game_page_loaded=yes')
except Exception as e:
    print('game_page_loaded=no error=%s' % e)
