#!/usr/bin/env python3
print('[victim] Neu target-web in GRANTED_ADMIN --> tan cong thanh cong!')
print('verify_complete=yes')
