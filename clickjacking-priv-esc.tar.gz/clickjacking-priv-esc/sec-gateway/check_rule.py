#!/usr/bin/env python3
text = open('clickjack.rules').read()
checks = {
    'co_rule_clickjacking' : "CLICKJACKING" in text,
    'co_sid_2002001'       : 'sid:2002001' in text,
    'co_kiem_tra_admin_uri': '/admin/' in text,
    'co_kiem_tra_referer'  : 'Referer' in text and '192.168.10.' in text,
    'co_rule_thieu_header' : 'X-Frame-Options' in text,
}
print('=== Kiem tra Luat Suricata ===')
for name, ok in checks.items():
    print('  %-30s = %s' % (name, 'yes' if ok else 'NO'))
print('clickjack_rule_created=%s' % ('yes' if all(checks.values()) else 'no'))
