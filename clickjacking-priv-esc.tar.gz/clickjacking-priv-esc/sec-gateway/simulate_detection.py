#!/usr/bin/env python3
sample_logs = [
    '192.168.10.10 - - "GET /admin/settings HTTP/1.1" 200 512 "http://192.168.10.50/game.html"',
    '192.168.10.10 - - "POST /admin/settings/grant-admin HTTP/1.1" 200 24 "http://192.168.10.50/game.html"',
    '172.20.0.20  - - "GET /admin/settings HTTP/1.1" 200 512 "-"',
]
print('=== Phan Tich Access Log ===')
detected = False
for log in sample_logs:
    if 'POST' in log and '/admin/' in log and '192.168.10.' in log:
        print('[CANH BAO] ' + log)
        print('  --> TAN CONG CLICKJACKING phat hien!')
        detected = True
    else:
        print('[OK]       ' + log)
print('clickjack_detected=%s' % ('yes' if detected else 'no'))
