#!/bin/bash
echo "target_started=yes"
echo "[target-web] Khoi dong web server tai http://172.20.0.10"
sudo python3 /home/ubuntu/target_server.py
