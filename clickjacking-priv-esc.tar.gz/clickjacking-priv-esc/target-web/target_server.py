#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs
import hashlib, os, json, time, traceback
PORT = 80
USERS = {"student": "password123"}
sessions = {}
admin_granted_log = []
def make_session(username):
    token = hashlib.sha256((username + str(time.time())).encode()).hexdigest()[:32]
    sessions[token] = username
    return token
def get_user(headers):
    cookie = headers.get('Cookie', '')
    for part in cookie.split(';'):
        p = part.strip()
        if p.startswith('session='):
            return sessions.get(p[8:])
    return None
LOGIN_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Dang Nhap - Cong Dao Tao</title>
<style>
body{font-family:sans-serif;background:#1a237e;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.box{background:#fff;color:#333;padding:30px;border-radius:10px;width:320px;text-align:center}
input{width:90%;padding:10px;margin:8px 0;border:1px solid #ccc;border-radius:5px}
button{width:95%;padding:10px;background:#1a237e;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold}
</style>
</head>
<body>
<div class="box">
  <h2>Cong Dao Tao</h2>
  <form method="POST" action="/login">
    <input type="text" name="username" value="student" required><br>
    <input type="password" name="password" value="password123" required><br>
    <button type="submit">Dang Nhap</button>
  </form>
</div>
</body>
</html>"""
DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<style>
body{font-family:sans-serif;background:#f5f6fa;margin:0;padding:20px;text-align:center}
.card{background:#fff;padding:40px;border-radius:10px;display:inline-block;box-shadow:0 2px 10px rgba(0,0,0,0.1)}
</style>
</head>
<body>
<div class="card">
  <h2>Xin chao, student! &#128075;</h2>
  <p>Ban da dang nhap thanh cong.</p>
</div>
</body>
</html>"""
ADMIN_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
body{margin:0;padding:0;background:transparent}
form{margin:0;padding:0}
.btn-grant{
  width:220px;height:48px;
  background:#b71c1c;color:#fff;
  border:none;border-radius:8px;
  font-size:16px;font-weight:bold;cursor:pointer;
}
</style>
</head>
<body>
<form method="POST" action="/admin/settings/grant-admin">
  <button class="btn-grant" type="submit">Cap Quyen Admin</button>
</form>
</body>
</html>"""
GRANTED_HTML = """<!DOCTYPE html>
<html><body style="font-family:sans-serif;text-align:center;padding:20px;background:#fff">
<h3 style="color:#b71c1c">&#9989; Da cap quyen Admin thanh cong!</h3>
</body></html>"""
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            p = self.path.split('?')[0]
            if p in ('/', '/login'):
                self._send(200, LOGIN_HTML.encode('utf-8'), 'text/html')
            elif p == '/dashboard':
                self._send(200, DASHBOARD_HTML.encode('utf-8'), 'text/html')
            elif p == '/admin/settings':
                # Lo hong thieu X-Frame-Options
                self._send(200, ADMIN_HTML.encode('utf-8'), 'text/html')
            elif p == '/status':
                status = {'admin_granted': len(admin_granted_log) > 0,
                          'count': len(admin_granted_log),
                          'entries': admin_granted_log[-5:]}
                self._send(200, json.dumps(status).encode('utf-8'), 'application/json')
            else:
                self._send(404, b'Not found', 'text/plain')
        except Exception:
            traceback.print_exc()
            self._send(500, b'Server Error', 'text/plain')
    def do_POST(self):
        try:
            p = self.path.split('?')[0]
            referer = self.headers.get('Referer', '-')
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length).decode(errors='ignore')
            if p == '/login':
                token = make_session("student")
                self.send_response(302)
                self.send_header('Location', '/dashboard')
                self.send_header('Set-Cookie', 'session=%s; Path=/; SameSite=None' % token)
                self.end_headers()
                print('LOGIN_SUCCESS user=student')
            elif p == '/admin/settings/grant-admin':
                entry = {'user': 'student', 'referer': referer, 'time': time.strftime('%H:%M:%S')}
                admin_granted_log.append(entry)
                is_clickjack = '192.168.10.' in referer
                print('GRANTED_ADMIN user=student referer=%s clickjacking=%s' % (
                    referer, 'YES' if is_clickjack else 'no'))
                self._send(200, GRANTED_HTML.encode('utf-8'), 'text/html')
            else:
                self._send(404, b'Not found', 'text/plain')
        except Exception:
            traceback.print_exc()
            self._send(500, b'Server Error', 'text/plain')
    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header('Content-Type', ctype + '; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
print('target_started=yes')
print('[target-web] Server listening on port 80...')
HTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
HTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
