=== TARGET-WEB (172.20.0.10) ===
Lenh khoi dong: ./run_target.sh

Cac trang:
  http://172.20.0.10/login          - Trang dang nhap
  http://172.20.0.10/dashboard      - Trang chu (sau khi login)
  http://172.20.0.10/admin/settings - Trang admin (bi lo hong clickjacking)
  http://172.20.0.10/status         - Xem trang thai tan cong (JSON)

Tai khoan demo:
  student    / password123
  giaovien   / teacher456
