#!/usr/bin/env python3
from http.server import SimpleHTTPRequestHandler, HTTPServer
import os

os.chdir('/home/ubuntu')

class H(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print('ATTACKER LOG [%s]: %s' % (self.client_address[0], fmt % args))

print('attacker_started=yes')
print('[attacker-web] Clickjacking server: http://192.168.10.50')
print('[attacker-web] Trang bay: http://192.168.10.50/game.html')
HTTPServer(('0.0.0.0', 80), H).serve_forever()
