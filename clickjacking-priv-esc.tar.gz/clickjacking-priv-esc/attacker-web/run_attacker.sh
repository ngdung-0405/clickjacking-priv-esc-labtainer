#!/bin/bash
echo "attacker_started=yes"
echo "[attacker-web] Khoi dong Clickjacking server tai http://192.168.10.50"
sudo python3 /home/ubuntu/attacker_server.py
